function updateLocalStorage(employee) {
  let employees = JSON.parse(localStorage.getItem("employees")) || [];

  const existingIndex = employees.findIndex(emp => emp.id === employee.id);
  if (existingIndex !== -1) {
    employees[existingIndex] = employee;
    addOrUpdateEmployee(employee); // Update existing employee
  } else {
    employees.push(employee);
    addOrUpdateEmployee(employee); // Add new employee
  }

  localStorage.setItem("employees", JSON.stringify(employees));

  clearForm();
  updateAdvanceTable();
}
